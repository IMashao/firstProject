package za.co.absa.homeloans.nucleus.selenium.helpers;

public class DashBoardElements {

    public final String inventoryPageTab ="mat-tab-group_0_ruf-menu-label_1_div_0_ruf-labeled-icon_0_mat-icon_0";
    public final String sidemenuElement="/html/body/nextgen-root/div/ruf-app-canvas/nextgen-layout/mat-sidenav-container/mat-sidenav-content/div[1]/mat-icon";
    public final String manageDashboardButton="manageDashboardLink_span_0";
    public final String blankDashboardButton="/html/body/nextgen-root/div/ruf-app-canvas/nextgen-layout/mat-sidenav-container/mat-sidenav-content/div[2]/div/nextgen-manage-dashboard/dpsfui-dashboard-management/div/mat-card[1]/div/mat-card";
    public final String deleteDashboard="//button[@aria-label='Delete dashboard button']";


    public final String dashBoardName="//input[@formcontrolname='name']";
    public final String dashboardDescription="//input[@formcontrolname='description']";
    public final String next1Button="//span[@class='mat-button-wrapper'][contains(.,'Next >')]";

    public final String barchartElement="//*[@id=\"cdk-step-content-0-1\"]/dpsfui-content-step/form/div[1]/div[2]/div/mat-card[1]";

    public final String modelDropDown="//*[@id=\"mat-select-1\"]";
    public final String modelDropDownOption="//*[@id=\"mat-option-7\"]";

    public final String aggreationDropdown="//*[@id=\"mat-select-3\"]";
    public final String aggregationDropdownOption="(//span[contains(@class,'mat-option-text')])[1]";

    public final String groubByDropdown="//*[@id=\"mat-select-2\"]";
    public final String groupByDropdownOption="//span[@class='mat-option-text'][contains(.,'ACCOUNT NO')]";
    //span[@class='mat-option-text'][contains(.,'Amount')]

    public final String addChart="//*[@id=\"cdk-step-content-0-1\"]/dpsfui-content-step/form/div[2]/div/div[3]/button";

    public final String next2="//span[@class='mat-button-wrapper'][contains(.,'Next >')]";

}
