package za.co.absa.homeloans.nucleus.selenium;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import za.co.absa.homeloans.automation.nucleus.data.DataClient;
import za.co.absa.homeloans.automation.nucleus.selenium.SeleniumClient;
import za.co.absa.homeloans.nucleus.selenium.helpers.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import static org.junit.Assert.fail;

public class CreateApplicationEndToEndTest {

    private JavascriptExecutor javascriptExecutor;

    public ExtentHtmlReporter htmlReporter;
    public ExtentReports extent;
    public ExtentTest test;
    boolean testStatus = true;

    WebDriver driver;
    Properties environment = new Properties();
    ArrayList<HashMap<String, String>> testData = new ArrayList<>();
    DashBoardElements dashBoardElements =new DashBoardElements();
    ReconElement reconElement = new ReconElement();
    ModelElements modelElements= new ModelElements();

    SeleniumClient seleniumClient = new SeleniumClient();

    @Before
    public void before() {
        environment = DataClient.getProperties("src/test/resources/environment.properties");
        testData = DataClient.getAllRowsFromExcelFile("src/test/resources/createApplicationEndToEnd.xlsx", "Master");

        extent = new ExtentReports();
        htmlReporter = new ExtentHtmlReporter(environment.getProperty("reports") + "ApplicationTestEndToEnd.html");
        extent = new ExtentReports();
        htmlReporter.config().setDocumentTitle("Application report end to end");
        htmlReporter.config().setTheme(Theme.STANDARD);
    }

    private WebDriver driver() {
        return this.driver = driver;
    }
    @Test
    public void seleniumTest() throws Exception {
        SeleniumClient seleniumClient = new SeleniumClient();
        driver = seleniumClient.getChromeDriver();
        driver.manage().window().maximize();
        driver.get(environment.getProperty("baseUrl"));
        javascriptExecutor = (JavascriptExecutor) driver;


        test = extent.createTest("Login In");
        HashMap<String, String> loginDetails = DataClient.getAllRowsFromExcelFileById("src/test/resources/createApplicationEndToEnd.xlsx", "Login", testData.get(0).get("TestID")).get(0);
        //logining in
        if (Login.login(driver, loginDetails, test, environment)) {
            testStatus = true;
        } else {
            //test failed
            testStatus = false;
            fail("Test failed to login and aborted");
        }

        test = extent.createTest("Verify Dash Board Creation");
        if (CreateDashboard.ClickSideMenu(driver, loginDetails, test, environment)) {
            testStatus = true;
        } else {
            testStatus = false;
            fail("Test failed to click side menu");
        }

        if (CreateDashboard.clickManageDashboardo(driver, loginDetails, test, environment)) {
            testStatus = true;
        } else {
            testStatus = false;
            fail("Test failed to go to dashboard page");
        }

       // test = extent.createTest("New Bank Dash Board Creation");
       if (CreateDashboard.createBlankDashboard(driver, loginDetails, test, environment)) {
           testData = DataClient.getAllRowsFromExcelFile("src/test/resources/IntellimatchTestData.xlsx", "DashBoard");

           for (int i = 0; i < testData.size(); i++) {

                   testData = DataClient.getAllRowsFromExcelFile("src/test/resources/IntellimatchTestData.xlsx", "DashBoard");
                   // passing test
                   if (SeleniumClient.checkIfElementIsVisible(driver, By.xpath(dashBoardElements.dashBoardName))) {
                       driver.findElement(By.xpath(dashBoardElements.dashBoardName)).sendKeys(testData.get(i).get("Name"));
                       driver.findElement(By.xpath(dashBoardElements.dashboardDescription)).sendKeys(testData.get(i).get("Description"));
                       test.pass("Success filling up dashboard form credentials", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                   } else {
                       test.fail("Failed filling up dashboard form credentials", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                   }

           }

               driver.findElement(By.xpath(dashBoardElements.next1Button)).click();
                Thread.sleep(2000);
               if (SeleniumClient.checkIfElementIsVisible(driver, By.xpath(dashBoardElements.barchartElement))) {
                   driver.findElement(By.xpath(dashBoardElements.barchartElement)).click();

                   Thread.sleep(2000);

                   //Model drop down

                   for (int i = 0; i < testData.size(); i++) {
                       testData = DataClient.getAllRowsFromExcelFile("src/test/resources/IntellimatchTestData.xlsx", "DashBoardContent");
                       // passing test
                       if (SeleniumClient.checkIfElementIsVisible(driver, By.xpath(dashBoardElements.modelDropDown))) {
                           driver.findElement(By.xpath(dashBoardElements.modelDropDown)).click();
                           if(testData.get(i).get("Model").equals("Commodities_Securities"))
                           {
                               Thread.sleep(3000);
                               driver.findElement(By.xpath(dashBoardElements.modelDropDownOption)).click();
                           }
                       } else {
                           test.fail("Failed to click dropdown", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                       }
                       break;
                   }
                   Thread.sleep(2000);

                   //Aggregation
                   for (int i = 0; i < testData.size(); i++) {
                       testData = DataClient.getAllRowsFromExcelFile("src/test/resources/IntellimatchTestData.xlsx", "DashBoardContent");
                       // passing test
                       if (SeleniumClient.checkIfElementIsVisible(driver, By.xpath(dashBoardElements.aggreationDropdown))) {
                           driver.findElement(By.xpath(dashBoardElements.aggreationDropdown)).click();
                           if(testData.get(i).get("Aggregation").equals("Count"))
                            {
                                driver.findElement(By.xpath(dashBoardElements.aggregationDropdownOption)).click();
                            }
                       } else {
                           test.fail("Failed to click dropdown", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                       }
                       break;
                   }
                    Thread.sleep(3000);
                   //Group By

                   for (int i = 0; i < testData.size(); i++) {
                       testData = DataClient.getAllRowsFromExcelFile("src/test/resources/IntellimatchTestData.xlsx", "DashBoardContent");
                       // passing test
                       if (SeleniumClient.checkIfElementIsVisible(driver, By.xpath(dashBoardElements.groubByDropdown))) {
                           driver.findElement(By.xpath(dashBoardElements.groubByDropdown)).click();
                           if(testData.get(i).get("Group By").equals("Account"))
                           {
                               Thread.sleep(2000);
                               driver.findElement(By.xpath(dashBoardElements.groupByDropdownOption)).click();
                           }
                       } else {
                           test.fail("Failed to click dropdown", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                       }
                       break;
                   }
                   driver.findElement(By.xpath(dashBoardElements.addChart)).click();
                   test.pass("Success Content Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
               } else {
                   test.fail("Content Page Failed to Load", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
               }

               driver.findElement(By.xpath(dashBoardElements.next2)).click();
               Thread.sleep(2000);
               test.pass("Success Review screen", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
               driver.findElement(By.xpath("//button[@color='primary'][contains(.,'Finish')]")).click();

               if (SeleniumClient.checkIfElementIsVisible(driver, By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted'][contains(.,'Dashboard created successfully.')]"))) {
                   test.pass("Success DashBoard created ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

               } else {
                   test.pass("Failed to create DashBoard Review ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

               }
               testStatus = true;
       }
       else
       {
           testStatus = false;
           fail("Test failed to go to dashboard page");
       }

        test = extent.createTest("Verify Delete Dashboard");
        if(CreateDashboard.deleteDashboard(driver, loginDetails, test, environment))
        {
            testStatus=true;
        }
        else
        {
            testStatus = false;
            fail("Test failed to delete dashboard");
        }

        test = extent.createTest("Verify Recon Assignment");
        if (ReconAssignment.assignRecon(driver, loginDetails, test, environment)) {
            testData = DataClient.getAllRowsFromExcelFile("src/test/resources/IntellimatchTestData.xlsx", "Users");

            for (int i = 0; i < testData.size(); i++) {
                // passing test
                driver.findElement(By.xpath("//div[@class='mat-form-field-infix'][contains(.,'Search Users')]")).click();
                driver.findElement(By.xpath("(//span[contains(@class,'mat-option-text')])[1]")).click();
                driver.findElement(By.xpath(reconElement.clickAssign)).click();
                Thread.sleep(2000);
                driver.findElement(By.xpath(reconElement.saveReconbtn)).click();
                Thread.sleep(2000);
                if(SeleniumClient.checkIfElementIsVisible(driver,By.xpath(reconElement.reconsavedIconMessege)))
                {
                    test.pass("Success Recon Saved ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                }
                else
                {
                    test.fail("Failed to save recon  ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                }
            }
        }
        else
        {
        testStatus=false;
        }



        test=extent.createTest("Can match Partial items");
        if(Model.canMatchPartials(driver, loginDetails, test, environment))
        {
            testStatus=true;
        }
        else
        {
            testStatus=false;
        }

                test=extent.createTest("Verify Recon Approval");
        if(ReconAssignment.verifyReconApprovalButton(driver, loginDetails, test, environment))
        {
            testStatus=true;
        }
        else
        {
            testStatus=false;
        }

        test=extent.createTest("Verify Recon Reject");
        if(ReconAssignment.verifyReconRejectlButton(driver, loginDetails, test, environment))
        {
            testStatus=true;
        }
        else
        {
            testStatus=false;
        }

        test=extent.createTest("Verify if Can set manual match options for the Model");
        if(ReconAssignment.setManualMatchOptions(driver, loginDetails, test, environment))
        {
            testStatus=true;
        }
        else
        {
            testStatus=false;
        }

        test=extent.createTest("Verify Recon Summary with fields");
        if(ReconAssignment.checkReconSummeryWithFields(driver, loginDetails, test, environment))
        {
            testStatus=true;
        }
        else
        {
            testStatus=false;
        }
        test=extent.createTest("Verify Recon details and calculations");
        if(ReconAssignment.CanViewReconDetailsAndCalculations(driver, loginDetails, test, environment))
        {
            testStatus=true;
        }
        else
        {
            testStatus=false;
        }


        test=extent.createTest("Verify Sort data per column");
        if(ReconAssignment.verifySortingDataOnActivityPage(driver, loginDetails, test, environment))
        {
            testStatus=true;
        }
        else
        {
            testStatus=false;
        }



//        test=extent.createTest("Verify Create SnapshotModel");
//        if(Model.createSnapshotModel(driver, loginDetails, test, environment))
//        {
//            testData = DataClient.getAllRowsFromExcelFile("src/test/resources/IntellimatchTestData.xlsx", "SnapshotModelCreation");
//
//            for (int i = 0; i < testData.size(); i++) {
//                // passing test
//                driver.findElement(By.xpath(modelElements.modelName)).sendKeys(testData.get(i).get("Model Name"));
//                Thread.sleep(2000);
//                driver.findElement(By.xpath(modelElements.reconSides)).click();
//                driver.findElement(By.xpath(modelElements.reconsideType)).click();
//                Thread.sleep(1000);
//                //frequency
//                driver.findElement(By.xpath(modelElements.frequency)).click();
//                driver.findElement(By.xpath(modelElements.frequencyName)).click();
//                Thread.sleep(1000);
//                //description
//                driver.findElement(By.xpath(modelElements.modelDescription)).sendKeys(testData.get(i).get("Model Description"));
//                //application service
//                Thread.sleep(1000);
//                driver.findElement(By.xpath(modelElements.applicationService)).click();
//                driver.findElement(By.xpath(modelElements.getApplicationServiceType)).click();
//                Thread.sleep(1000);
//
//                //company
//                driver.findElement(By.xpath(modelElements.company)).click();
//                driver.findElement(By.xpath(modelElements.getCompanyName)).click();
//                Thread.sleep(1000);
//
//                //Context
//                driver.findElement(By.xpath(modelElements.context)).click();
//                driver.findElement(By.xpath(modelElements.contextOption)).click();
//                Thread.sleep(1000);
//                //reconType
//                driver.findElement(By.xpath(modelElements.reconType)).click();
//                driver.findElement(By.xpath(modelElements.reconTypeOption)).click();
//                Thread.sleep(1000);
//                //roll balances
//                driver.findElement(By.xpath(modelElements.rollBalancesReconDate)).click();
//                driver.findElement(By.xpath(modelElements.getRollBalancesReconDateOption)).click();
//                Thread.sleep(1000);
//                //recon field
//                driver.findElement(By.xpath(modelElements.itemReconciliationField)).click();
//                driver.findElement(By.xpath(modelElements.getItemReconciliationFieldOption)).click();
//                Thread.sleep(1000);
//                //item date
//                driver.findElement(By.xpath(modelElements.itemDateField)).click();
//                driver.findElement(By.xpath(modelElements.getItemReconciliationFieldOption)).click();
//                Thread.sleep(1000);
//                //account balance field
//                driver.findElement(By.xpath(modelElements.accountBalanceField)).click();
//                driver.findElement(By.xpath(modelElements.getAccountBalanceFieldOption)).click();
//                Thread.sleep(1000);
//                //determine reconcilation date by most
//                driver.findElement(By.xpath(modelElements.determineReconciliationDateByMost)).click();
//                driver.findElement(By.xpath(modelElements.getDetermineReconciliationDateByMostOption)).click();
//                Thread.sleep(1000);
//                //latest date where
//                driver.findElement(By.xpath(modelElements.latestDateWhere)).click();
//                driver.findElement(By.xpath(modelElements.getLatestDateWhereOption)).click();
//                Thread.sleep(1000);
//                //determine date independency
//                driver.findElement(By.xpath(modelElements.determineDsteIndependency)).click();
//                driver.findElement(By.xpath(modelElements.getDetermineDsteIndependencyOption)).click();
//
//                driver.findElement(By.xpath(modelElements.createRecon)).click();
//                test.pass("Populated Form", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
//
//
//                if(SeleniumClient.checkIfElementIsVisible(driver,By.xpath(modelElements.modelSaved)))
//                {
//                    test.pass("Snapshot Model created ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
//
//                }
//                else
//                {
//                    test.fail("Snapshot Model Filed", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
//
//                }
//
//            }
//            testStatus=true;
//        }
//        else
//        {
//            testStatus=false;
//        }

        //conteneouse
//        test=extent.createTest("Verify Create Continuous Model");
//        if(Model.createSnapshotModel(driver, loginDetails, test, environment))
//        {
//            testData = DataClient.getAllRowsFromExcelFile("src/test/resources/IntellimatchTestData.xlsx", "ContinousModel");
//            //Enter Name
//            for (int i = 0; i < testData.size(); i++) {
//                // passing test
//                driver.findElement(By.xpath(modelElements.modelName)).sendKeys(testData.get(i).get("Model Name"));
//                break;
//            }
//
//            //Select Mode
//            for (int i = 0; i < testData.size(); i++) {
//                // passing test
//                Thread.sleep(2000);
//                if(testData.get(i).get("Mode").equals("Continuous"))
//                {
//                    driver.findElement(By.xpath(modelElements.ModelMode)).click();
//                    driver.findElement(By.xpath(modelElements.modelModeType)).click();
//                }
//                else
//                {
//                    test.fail("Failed to click recon side", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
//                }
//                break;
//            }
//
//
//            //select recon side
//            for (int i = 0; i < testData.size(); i++) {
//                // passing test
//                Thread.sleep(2000);
//                if(testData.get(i).get("Recon sides").equals("2 Sided"))
//                {
//                    driver.findElement(By.xpath(modelElements.reconSides)).click();
//                    driver.findElement(By.xpath(modelElements.reconsideType)).click();
//                }
//                else
//                {
//                    test.fail("Failed to click recon side", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
//
//                }
//                break;
//            }
//            //description
//            for (int i = 0; i < testData.size(); i++) {
//                // passing test
//                driver.findElement(By.xpath(modelElements.modelDescription)).sendKeys(testData.get(i).get("Model Description"));
//                break;
//            }
//            //application service
//            for (int i = 0; i < testData.size(); i++) {
//                // passing test
//                Thread.sleep(2000);
//                if(testData.get(i).get("Applicatio  Service").equals("Reconciliation CIB_PROD"))
//                {
//                    driver.findElement(By.xpath(modelElements.applicationService)).click();
//                    driver.findElement(By.xpath(modelElements.getApplicationServiceType)).click();
//                }
//                else
//                {
//                    test.fail("Failed to click application service", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
//                }
//                break;
//            }
//
//            //company
//            for (int i = 0; i < testData.size(); i++) {
//                // passing test
//                Thread.sleep(2000);
//                if(testData.get(i).get("Comapany").equals("ABSA Capital Securities [ACS]"))
//                {
//                    driver.findElement(By.xpath(modelElements.company)).click();
//                    driver.findElement(By.xpath(modelElements.getCompanyName)).click();
//                }
//                else
//                {
//                    test.fail("Failed to click company", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
//                }
//                break;
//            }
//
//            //context
//            for (int i = 0; i < testData.size(); i++) {
//                // passing test
//                Thread.sleep(2000);
//                if(testData.get(i).get("Context").equals("Cash"))
//                {
//                    driver.findElement(By.xpath(modelElements.context)).click();
//                    driver.findElement(By.xpath(modelElements.contextOption)).click();
//                }
//                else
//                {
//                    test.fail("Failed to click context", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
//                }
//                break;
//            }
//
//            //Continueous Configuration
//            for (int i = 0; i < testData.size(); i++) {
//                // passing test
//                Thread.sleep(2000);
//                if(testData.get(i).get("Continuous Configuration").equals("Eq Amount"))
//                {
//                    driver.findElement(By.xpath(modelElements.continusCnfiguration)).click();
//                    driver.findElement(By.xpath(modelElements.continusCnfigurationType)).click();
//                    test.pass("Populated Form", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
//                    driver.findElement(By.xpath(modelElements.continueouseCreateButton)).click();
//
//                    if(SeleniumClient.checkIfElementIsVisible(driver,By.xpath("//span[contains(.,'Model saved successfully.')]")))
//                    {
//                        test.pass("Continueouse Model Created", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
//                    }
//                    else
//                    {
//                        test.fail("Continueouse Model Fail", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
//                    }
//                }
//                else
//                {
//                    test.fail("Failed to click context", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
//                }
//                break;
//            }
//
//        }


        test=extent.createTest("Edit Model OverView");
        if(Model.editModelOverview(driver, loginDetails, test, environment)) {
            testData = DataClient.getAllRowsFromExcelFile("src/test/resources/IntellimatchTestData.xlsx", "ModelOverviewEdit");
            //Enter Name
            for (int i = 0; i < testData.size(); i++) {
                // passing test
                Thread.sleep(2000);
                driver.findElement(By.xpath(modelElements.editedModelName)).sendKeys(testData.get(i).get("EditedModelName"));
                break;
            }
            test.pass("Model Edit Form", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

            driver.findElement(By.xpath(modelElements.saveModelAfterEdit)).click();
            if(SeleniumClient.checkIfElementIsVisible(driver,By.xpath(modelElements.editedModelMessegeSuccess)))
            {
                test.pass("Model Edited", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            }
            else
            {
                test.fail("Model Couldnt be edited", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            }
        }
        else
        {
            testStatus=false;
        }

        /////////////here

//        test=extent.createTest("Verify Approval of Proposed Match Group");
//        if(Model.ApproveMatchGroup(driver, loginDetails, test, environment))
//        {
//            testStatus=true;
//        }
//        else
//        {
//            testStatus=false;
//        }

       //matching write off items

//        test=extent.createTest("Can match write off items");
//        if(Model.canMatchWriteOffItems(driver, loginDetails, test, environment))
//        {
//            testStatus=true;
//        }
//        else
//        {
//            testStatus=false;
//        }



        test=extent.createTest("Verify Ability to view dashboard");
        if(Model.viewDashBoard(driver, loginDetails, test, environment))
        {
            testStatus=true;
        }
        else
        {
            testStatus=false;
        }

//        test=extent.createTest("Can Perform Many Match Group");
//        if(Model.canPeformManyMatchGroup(driver, loginDetails, test, environment))
//        {
//            testStatus=true;
//        }
//        else
//        {
//            testStatus=false;
//        }


//        test=extent.createTest("Can Perform Unbalanced Match Group");
//        if(Model.canPeformUnbalancedMatchGroup(driver, loginDetails, test, environment))
//        {
//            testStatus=true;
//        }
//        else
//        {
//            testStatus=false;
//        }



//        test=extent.createTest("Can Filter");
//        if(Model.canFilter(driver, loginDetails, test, environment))
//        {
//            testStatus=true;
//        }
//        else
//        {
//            testStatus=false;
//        }


//        test=extent.createTest("Verify Collections");
//        if(Model.Collections(driver, loginDetails, test, environment))
//        {
//            testStatus=true;
//        }
//        else
//        {
//            testStatus=false;
//        }


//        test=extent.createTest("Verify Assign Items");
//        if(Model.AssignItems(driver, loginDetails, test, environment))
//        {
//            testStatus=true;
//        }
//        else
//        {
//            testStatus=false;
//        }



//        test=extent.createTest("Verify  Bulk Action with Assignment/Exception");
//        if(Model.BulkActionsAssignment(driver, loginDetails, test, environment))
//        {
//            testStatus=true;
//        }
//        else
//        {
//            testStatus=false;
//        }


//        test=extent.createTest("Verify adding SLA");
//        if(Model.addingSLA(driver, loginDetails, test, environment))
//        {
//            testStatus=true;
//        }
//        else
//        {
//            testStatus=false;
//        }
    }
    public void reinitializeDriver(WebDriver driver) {
        driver.get(environment.getProperty("baseUrl"));
    }

    @After
    public void endTest() {
        extent.attachReporter(htmlReporter);
        extent.flush();
        if(!testStatus){
            fail("One or More Tests Failed - Please Check Report For Further Details");
        }
    }
    public void clickElement(By by){
        try{
            WebElement webElement = driver.findElement(by);
            ((JavascriptExecutor) driver()).executeScript("arguments[0].focus();", webElement);
            webElement.click();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
