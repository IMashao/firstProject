package za.co.absa.homeloans.nucleus.selenium.helpers;

public class ReconElement {

    //Recon Assignment
    public final String inventoryPageTab ="mat-tab-group_0_ruf-menu-label_1_div_0_ruf-labeled-icon_0_mat-icon_0";
    public final String homePageTab="//mat-icon[@ng-reflect-font-icon='fis-icon-home']";

    public final String reconSelectArrow="(//mat-icon[contains(@class,'fis-icon-rotate-270 mat-icon notranslate fisfont fis-icon-chevron-double mat-icon-no-color')])[10]";

    public final String  cliclProcess="//*[@id=\"dynamic_sidemenu_processes_0\"]";
    public final String clickAssignment="//*[@id=\"dynamic_sidemenu_processes_children_0_a_0\"]";
    public final String  searchUsersText="//input[contains(@class,'mat-input-element mat-form-field-autofill-control cdk-text-field-autofill-monitored ng-pristine ng-valid ng-touched')]";
    public final  String clickAssign="//span[contains(.,'person_add Assign')]";
    public final String saveReconbtn="//span[@class='mat-button-wrapper'][contains(.,'Save Recon')]";
    public final String reconsavedIconMessege="//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted'][contains(.,'Saved Successfully.')]";


    public  final String  model="//span[@class='cursor-pointer model-name'][contains(.,'AbCap CIBW - Debit Card Suspense_Cash')]";
    public final  String matchingMenu="//ruf-labeled-icon[contains(.,'Matching')]";

    public final String addFieldButton="//mat-icon[contains(@ng-reflect-fis-icon,'add')]";
    public final String addFieldTextF="//input[contains(@id,'mat-chip-list-input-0')]";
    public final String selectedAddedField="(//span[@class='mat-option-text'])[2]";
    public final String saveModelbtn="//span[contains(.,'Save Model')]";
    public final String modelsavedSuccess="//span[contains(.,'Saved Successfully.')]";


    public final String clickPresentationBTN="//span[contains(.,'Presentation')]";
    public final String clickSummeryBTN="//span[contains(@id,'0')][contains(.,'Summary')]";
    public final String tickAndUntickFiel="(//div[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin'])[5]";
    public final String saveModel="//span[contains(.,'Save Model')]";
    public final String saveMessege="//span[contains(.,'Summary information saved successfully')]";

    public final String expandRecon="(//span[contains(@class,'ag-icon ag-icon-expanded')])[1]";
    public final String trialBalanceLBL="//td[@class='sideTitle ellipsis ng-star-inserted'][contains(.,'We Side')]";

    public final String activityPage="//span[@class='cursor-pointer primary'][contains(.,'ACS Funding_Recon')]";
    public final String sortByPrice="//*[@id=\"activityPageItemGrid_div_0_ag-grid-angular_0\"]/div/div[2]/div[1]/div[1]/div[2]/div/div/div[10]/div[2]";
    public final String ReconApproveButton="//*[@id=\"activityAccept\"]/span";
    public  final String reconApprovalButtonDialog="(//span[@class='mat-button-wrapper'][contains(.,'APPROVE')])[2]";
    public final String reconApprovedSuccess="//span[contains(.,'Saved Successfully.')]";



    public final String rejectReconButton="//*[@id=\"activityReject\"]";
    public final String reconCommentTextBox="//textarea[contains(@data-aid,'home-tab-recon-comment')]";
    public final String dialogreject2="//span[@class='mat-button-wrapper'][contains(.,'Reject')]";
    public final String rejectSuccessMessege="//snack-bar-container[contains(.,'Saved Successfully.')]";



}
