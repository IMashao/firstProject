package za.co.absa.homeloans.nucleus.selenium.helpers;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import za.co.absa.homeloans.automation.nucleus.data.DataClient;
import za.co.absa.homeloans.automation.nucleus.selenium.SeleniumClient;

import java.io.IOException;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

public class CreateDashboard {



public static   DashBoardElements dashBoardElements = new DashBoardElements();

    public static boolean ClickSideMenu(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        try {
            // passing test
            if (SeleniumClient.checkIfElementIsVisible(driver, By.id(dashBoardElements.inventoryPageTab))) {
                test.pass("Success landing page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                //positive testing
                if (SeleniumClient.checkIfElementIsVisible(driver, By.xpath(dashBoardElements.sidemenuElement))) {
                    driver.findElement(By.xpath(dashBoardElements.sidemenuElement)).click();
                    Thread.sleep(2000);
                    test.pass("Success clicked Side Menu", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                    return true;
                } else {
                    test.fail("Failed to click on side menu", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                    return false;
                }
            } else
            {
                //Fail test
                test.fail("Driver not on the right page ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                return false;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }


    public static boolean clickManageDashboardo(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment)
    {
        try {
            // passing test
            if (SeleniumClient.checkIfElementIsVisible(driver, By.id(dashBoardElements.manageDashboardButton))) {

                test.pass("Success Dash Board Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                //positive testing
                if (SeleniumClient.checkIfElementIsVisible(driver, By.id(dashBoardElements.manageDashboardButton))) {
                    driver.findElement(By.id(dashBoardElements.manageDashboardButton)).click();
                    Thread.sleep(2000);
                    test.pass("Success Dash Board Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                    return true;
                } else {
                    test.fail("Failed to click dash board", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                    return false;
                }
            } else
            {
                //Fail test
                test.fail("Driver not on the right page ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                return false;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }


    public static boolean createBlankDashboard(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        try {
            // passing test
            if (SeleniumClient.checkIfElementIsVisible(driver, By.xpath(dashBoardElements.blankDashboardButton))) {

                test.pass("Success Dash Board Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                //positive testing
                if (SeleniumClient.checkIfElementIsVisible(driver, By.xpath(dashBoardElements.blankDashboardButton))) {
                    driver.findElement(By.xpath(dashBoardElements.blankDashboardButton)).click();
                    Thread.sleep(2000);
                    test.pass("Success Blank DashBoard Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

                    return true;
                } else {
                    test.fail("Failed to click Blank dash board page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                    return false;
                }
            } else {
                //Fail test
                test.fail("Driver not on the right page ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                return false;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
        public static boolean deleteDashboard(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment)
        {
            try {
                // passing test
                if (SeleniumClient.checkIfElementIsVisible(driver, By.xpath(dashBoardElements.deleteDashboard))) {

                    test.pass("All DashBoard Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                    //positive testing
                    if (SeleniumClient.checkIfElementIsVisible(driver, By.xpath(dashBoardElements.deleteDashboard))) {
                        Thread.sleep(2000);
                        driver.findElement(By.xpath(dashBoardElements.deleteDashboard)).click();
                        Thread.sleep(2000);
                        if(SeleniumClient.checkIfElementIsVisible(driver,By.xpath("//span[contains(.,'Dashboard deleted successfully.')]")))
                        {
                            test.pass("Success Deleted DashBoard", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

                        }
                        else
                        {
                            test.fail("Failed to view all  dash board page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

                        }

                        return true;
                    } else {
                        test.fail("Failed to view all  dash board page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                        return false;
                    }
                } else
                {
                    //Fail test
                    test.fail("Driver not on the right page ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                    return false;
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                return false;
            }
        }
    }










