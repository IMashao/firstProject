package za.co.absa.homeloans.nucleus.selenium;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import za.co.absa.homeloans.automation.nucleus.data.DataClient;
import za.co.absa.homeloans.automation.nucleus.selenium.SeleniumClient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

public class LoginNewUserInterface {
    public ExtentHtmlReporter htmlReporter;
    public ExtentReports extent;
    public ExtentTest test;

    WebDriver driver;
    Properties environment = new Properties();
    ArrayList<HashMap<String, String>> testData = new ArrayList<>();

    SeleniumClient seleniumClient = new SeleniumClient();

    @Before
    public void before() {
        environment = DataClient.getProperties("src/test/resources/environment.properties");
        testData = DataClient.getAllRowsFromExcelFile("src/test/resources/IntellimatchTestData.xlsx", "Login");

        extent = new ExtentReports();
        htmlReporter = new ExtentHtmlReporter(environment.getProperty("reports") + "Login Report.html");
        extent = new ExtentReports();
        htmlReporter.config().setDocumentTitle("Login Report");
        htmlReporter.config().setTheme(Theme.STANDARD);
    }

    @Test
    public void seleniumTest() throws Exception {
        SeleniumClient seleniumClient = new SeleniumClient();
        driver = seleniumClient.getChromeDriver();
        driver.get(environment.getProperty("baseUrl"));

        for (int i = 0; i < testData.size(); i++) {
            test = extent.createTest(testData.get(i).get("TestID") + " " + testData.get(i).get("TestDescription"));

            if (SeleniumClient.checkIfElementIsVisible(driver, By.id("username"))) {
                driver.findElement(By.id("username")).clear();
                test.pass("Success landing page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

                driver.findElement(By.id("username")).sendKeys(testData.get(i).get("UserName"));
                driver.findElement(By.id("password")).sendKeys(testData.get(i).get("Password"));
                test.pass("Success adding credentials", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                driver.findElement(By.id("kc-login")).click();


                //Positive log in
                if (testData.get(i).get("ExpectedResult").equalsIgnoreCase("Success")) {
                    if (SeleniumClient.checkIfElementIsVisible(driver, By.id("input-name"))) {
                        test.pass("Success create application page ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

                        //Logout
                        driver.findElement(By.xpath("/html/body/app-root/app-main/div/div/app-topbar/div/div[2]/ul/li/a/i")).click();
                        driver.findElement(By.xpath("/html/body/app-root/app-main/div/div/app-topbar/div/div[2]/ul/li/ul/li/a")).click();
                        test.pass("Success logout ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

                    } else {
                        test.fail("Unsuccessful logging ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                        reinitializeDriver(driver);
                    }
                }
            } else {
                //Fail test
                reinitializeDriver(driver);
            }

            //negative test
            if (testData.get(i).get("ExpectedResult").equalsIgnoreCase("Fail")) {
                if (!SeleniumClient.checkIfElementIsVisible(driver,  By.id("input-name"))) {

                    test.pass("Success fail test 'Incorrect credentials were provided' ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                    //reinitializeDriver(driver);
                } else {
                    test.fail("Unsuccessful fail test 'Correct credentials were provided' ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                    driver.findElement(By.xpath("/html/body/app-root/app-main/div/div/app-topbar/div/div[2]/ul/li/a/i")).click();
                    driver.findElement(By.xpath("/html/body/app-root/app-main/div/div/app-topbar/div/div[2]/ul/li/ul/li/a")).click();
                    reinitializeDriver(driver);
                }
            }
        }
        driver.quit();

    }

    public void reinitializeDriver(WebDriver driver) {
        driver.get(environment.getProperty("baseUrl"));
    }

    @After
    public void endTest() {
        extent.attachReporter(htmlReporter);
        extent.flush();
    }
}
