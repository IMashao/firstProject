package za.co.absa.homeloans.nucleus.selenium.helpers;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import za.co.absa.homeloans.automation.nucleus.selenium.SeleniumClient;

import java.util.HashMap;
import java.util.Properties;

public class Login {

    public static boolean login(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        try {
            // passing test
            if (SeleniumClient.checkIfElementIsVisible(driver, By.id("mat-tab-group_0_ruf-menu-label_1_div_0_ruf-labeled-icon_0"))) {
                Thread.sleep(2000);
                test.pass("Success landing page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

                //fff
                //positive testing
                if (SeleniumClient.checkIfElementIsVisible(driver, By.id("button-bar-main_1_ruf-toolbar-row_0_mat-button-toggle-group_0_mat-button-toggle_0_im-button-content_0_div_0"))) {
                    return true;
                } else {
                    test.fail("Unsuccessful Home page landing ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                    return false;
                }
            } else
                {
                //Fail test
                test.fail("Driver not on the right page ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                return false;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
