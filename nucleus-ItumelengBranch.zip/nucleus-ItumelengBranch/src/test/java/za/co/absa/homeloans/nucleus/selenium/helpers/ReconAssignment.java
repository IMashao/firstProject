package za.co.absa.homeloans.nucleus.selenium.helpers;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import za.co.absa.homeloans.automation.nucleus.selenium.SeleniumClient;

import javax.swing.*;
import java.util.HashMap;
import java.util.Properties;

public class ReconAssignment {

    public static boolean assignRecon(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ReconElement reconElement= new ReconElement();

        try {
            // passing test
            if (SeleniumClient.checkIfElementIsVisible(driver, By.id(reconElement.inventoryPageTab))) {
                driver.findElement(By.id(reconElement.inventoryPageTab)).click();
                Thread.sleep(4000);
                test.pass(" Recon Inventory", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

                driver.findElement(By.xpath(reconElement.reconSelectArrow)).click();
                Thread.sleep(2000);
                test.pass("Activity Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

                driver.findElement(By.xpath(reconElement.cliclProcess)).click();
                Thread.sleep(2000);
                test.pass("Side Menu", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

                driver.findElement(By.xpath(reconElement.clickAssignment)).click();
                test.pass("Assignment", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

            } else
            {
                //Fail test
                test.fail("Failed to click on the recon Inventory ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                return false;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }
    public static boolean setManualMatchOptions(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ReconElement reconElement= new ReconElement();

        try {
            // passing test
            if (SeleniumClient.checkIfElementIsVisible(driver, By.id(reconElement.inventoryPageTab))) {
                driver.findElement(By.id(reconElement.inventoryPageTab)).click();
                Thread.sleep(3000);
                test.pass(" Recon Inventory", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                driver.findElement(By.xpath(reconElement.model)).click();
                Thread.sleep(3000);

                test.pass(" Model Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                driver.findElement(By.xpath("//ruf-labeled-icon[contains(.,'Process')]")).click();
                Thread.sleep(3000);

                test.pass(" Process Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                driver.findElement(By.xpath(reconElement.matchingMenu)).click();
                Thread.sleep(3000);

                test.pass(" Matching Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                Thread.sleep(2000);
                driver.findElement(By.xpath(reconElement.addFieldButton)).click();
                driver.findElement(By.xpath(reconElement.addFieldTextF)).click();
                test.pass(" Adding  match field", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                Thread.sleep(2000);
                driver.findElement(By.xpath(reconElement.selectedAddedField)).click();
                Thread.sleep(2000);
                driver.findElement(By.xpath(reconElement.saveModelbtn)).click();
                if(SeleniumClient.checkIfElementIsVisible(driver,By.xpath(reconElement.modelsavedSuccess)))
                {
                    test.pass(" Model saved success", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                }
                else
                {
                    test.fail("Failed saving Model", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                }
            } else
            {
                //Fail test
                test.fail("Failed to click on the recon Inventory ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                return false;
            }


        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }

    public static boolean checkReconSummeryWithFields(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ReconElement reconElement= new ReconElement();

        try {
            // passing test
                driver.findElement(By.xpath(reconElement.clickPresentationBTN)).click();
                Thread.sleep(1000);
                test.pass(" Presentation success", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                 driver.findElement(By.xpath(reconElement.clickSummeryBTN)).click();
                 Thread.sleep(1000);
                 test.pass(" Summery success", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                 driver.findElement(By.xpath(reconElement.tickAndUntickFiel)).click();
                Thread.sleep(1000);
                driver.findElement(By.xpath(reconElement.tickAndUntickFiel)).click();
                test.pass(" Fields Ticked success", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

                 driver.findElement(By.xpath(reconElement.saveModelbtn)).click();

                if(SeleniumClient.checkIfElementIsVisible(driver,By.xpath(reconElement.saveMessege)))
                {
                    test.pass(" Model saved success", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                }
                else {
                    test.fail(" Model Not saved ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                }

        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }

    public static boolean CanViewReconDetailsAndCalculations(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ReconElement reconElement= new ReconElement();
        try {
            // passing test
          driver.findElement(By.xpath(reconElement.homePageTab)).click();
          test.pass(" Home Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
          driver.findElement(By.xpath(reconElement.expandRecon)).click();
          if(SeleniumClient.checkIfElementIsVisible(driver,By.xpath(reconElement.trialBalanceLBL)))
          {
              test.pass("Recon Summery Success", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
          }
          else
          {
              test.fail("Recon Summery Failed", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
          }
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }


    public static boolean verifySortingDataOnActivityPage(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ReconElement reconElement= new ReconElement();
        try {
            // passing test
            driver.findElement(By.xpath(reconElement.activityPage)).click();
            Thread.sleep(6000);
            test.pass(" Activity Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            Thread.sleep(3000);
            driver.findElement(By.xpath(reconElement.sortByPrice)).click();
            Thread.sleep(4000);
            test.pass("Sorting Column", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }


    public static boolean verifyReconApprovalButton(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ReconElement reconElement= new ReconElement();
        try {

            driver.findElement(By.xpath("//span[@class='cursor-pointer primary'][contains(.,'ZAR Cashbooks')]")).click();
            Thread.sleep(3000);
            test.pass("Activity Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

            // passing test
            driver.findElement(By.xpath(reconElement.ReconApproveButton)).click();
            test.pass("Approve Dialog", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(reconElement.reconApprovalButtonDialog)).click();
            if(SeleniumClient.checkIfElementIsVisible(driver,By.xpath(reconElement.reconApprovedSuccess)))
            {
                test.pass("Recon Approved", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            }
            else
            {
                test.fail("Recon Failed", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }

    public static boolean verifyReconRejectlButton(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ReconElement reconElement= new ReconElement();
        try {

            driver.findElement(By.xpath("//span[@class='cursor-pointer primary'][contains(.,'ZAR Cashbooks')]")).click();
            Thread.sleep(3000);
            test.pass("Activity Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

            // passing test
            driver.findElement(By.xpath(reconElement.rejectReconButton)).click();
            Thread.sleep(1000);
            driver.findElement(By.xpath(reconElement.reconCommentTextBox)).sendKeys("Hello Dear we just rejeted this for testing ");
            Thread.sleep(1000);
            driver.findElement(By.xpath(reconElement.dialogreject2)).click();

            if(SeleniumClient.checkIfElementIsVisible(driver,By.xpath(reconElement.rejectSuccessMessege)))
            {
                test.pass("Recon Rejected", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            }
            else
            {
                test.fail("Recon Reject Failed", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }
}
