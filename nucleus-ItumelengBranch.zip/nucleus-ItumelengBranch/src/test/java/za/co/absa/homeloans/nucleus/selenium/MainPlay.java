package za.co.absa.homeloans.nucleus.selenium;

import javax.swing.*;
import java.util.Arrays;
import java.util.HashSet;

public class MainPlay {

    public static void main(String[] args) {

        String numbers = JOptionPane.showInputDialog(null,"Enter your value here");

        int num = Integer.parseInt(numbers);

        int[] arr = new int[10];

        for(int i =0 ;i<arr.length;i++)
        {
            arr[i]=num;
           ;
        }
        HashSet<Integer> set = new HashSet<Integer>();
        System.out.println( Arrays.asList(arr));


    }
}
