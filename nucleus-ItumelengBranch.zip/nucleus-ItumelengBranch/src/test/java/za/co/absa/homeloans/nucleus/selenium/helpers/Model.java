package za.co.absa.homeloans.nucleus.selenium.helpers;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import za.co.absa.homeloans.automation.nucleus.selenium.SeleniumClient;
import za.co.absa.homeloans.nucleus.selenium.CreateApplicationEndToEndTest;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



public class Model extends ModelElements{

    public static boolean createSnapshotModel(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ModelElements modelElements= new ModelElements();
        try {
            // passing test
            driver.findElement(By.xpath(modelElements.reconInventoryPage)).click();
            driver.findElement(By.xpath(modelElements.createModelButn)).click();
            test.pass("Model Form", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());


        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }

    public static boolean createContineousModel(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ModelElements modelElements= new ModelElements();
        try {
            // passing test
            driver.findElement(By.xpath(modelElements.reconInventoryPage)).click();
            driver.findElement(By.xpath(modelElements.createModelButn)).click();
            test.pass("Model Form", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());


        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }

    public static boolean editModelOverview(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ModelElements modelElements= new ModelElements();
        ReconElement reconElement= new ReconElement();
        try {
            // passing test
            driver.findElement(By.xpath(modelElements.reconInventoryPage)).click();
            driver.findElement(By.xpath(modelElements.selectModelToEdit)).click();
            test.pass("Model Form", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());


        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }

    public static boolean ApproveMatchGroup(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ModelElements modelElements= new ModelElements();
        try {
            // passing test
            driver.findElement(By.xpath(modelElements.homePageTab)).click();
            test.pass("Home Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.recon_GLD)).click();
            Thread.sleep(7000);

            test.pass("Activity Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());


            driver.findElement(By.xpath("//*[@id=\"activityPageItemGrid_div_0_ag-grid-angular_0\"]/div/div[2]/div[1]/div[3]/div[1]/div[32]/div/span/div[1]/mat-icon")).click();
            test.pass("Matched Items", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());


//            driver.findElement(By.xpath(modelElements.clickRecord1)).click();
//            driver.findElement(By.xpath(modelElements.clickRecord2)).click();
//            test.pass("Clicked Records", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
//            driver.findElement(By.xpath(modelElements.clickManualMatchBTN)).click();
//            test.pass("Match Dialog", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
//            driver.findElement(By.xpath(modelElements.approveMatchGroupBTN)).click();
//
//            if(SeleniumClient.checkIfElementIsVisible(driver,By.xpath(modelElements.matchgroupCreatedMessege)))
//            {
//                test.pass("Match Group Created", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
//            }
//            else
//            {
//                test.fail("Match Group Not Created", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
//            }

        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }


    public static boolean canMatchWriteOffItems(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ModelElements modelElements= new ModelElements();
        try {
            // passing test
            driver.findElement(By.xpath(modelElements.homePageTab)).click();
            test.pass("Home Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.recon_GLD)).click();
            Thread.sleep(5000);
            test.pass("Activity Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.clickRecord11)).click();
            driver.findElement(By.xpath(modelElements.clickRecord22)).click();
            test.pass("Clicked Records", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.clickManualMatchBTN)).click();
            Thread.sleep(2000);
            test.pass("Match Dialog", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.approveMatchGroupBTN)).click();

            if(SeleniumClient.checkIfElementIsVisible(driver,By.xpath(modelElements.proposedMessege)))
            {
                test.pass("Match Group Created", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            }
            else
            {
                test.fail("Match Group Not Created", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }


    public static boolean canMatchPartials(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ModelElements modelElements= new ModelElements();
        try {
            // passing test
            driver.findElement(By.xpath(modelElements.homePageTab)).click();
            test.pass("Home Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath("//span[@class='cursor-pointer primary'][contains(.,'ACS Funding_Recon')]")).click();
            Thread.sleep(5000);
            test.pass("Activity Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.clickRecord11)).click();
            driver.findElement(By.xpath(modelElements.clickRecord22)).click();
            test.pass("Clicked Records", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.clickManualMatchBTN)).click();
            test.pass("Match Dialog", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            Thread.sleep(2000);
            driver.findElement(By.xpath("//div[@class='mat-tab-label-content'][contains(.,'Partials')]")).click();

            driver.findElement(By.xpath(modelElements.proposeBTN)).click();

            if(SeleniumClient.checkIfElementIsVisible(driver,By.xpath(modelElements.proposedMessege)))
            {
                test.pass("Match Group Created", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            }
            else
            {
                test.fail("Match Group Not Created", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }
    public static boolean viewDashBoard(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ModelElements modelElements= new ModelElements();
        try {
            // passing test
            driver.findElement(By.xpath(modelElements.homePageTab)).click();
            test.pass("Home Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.sideMenu)).click();
            test.pass("Side Meu", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.dashboard)).click();
            Thread.sleep(2000);
            test.pass("DashBoards", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());


        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }

    public static boolean canPeformManyMatchGroup(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ModelElements modelElements= new ModelElements();
        ReconElement reconElement = new ReconElement();

        try {
            // passing test
            driver.findElement(By.xpath(modelElements.homePageTab)).click();
            test.pass("Home Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.recon_GLD)).click();
            Thread.sleep(7000);
            test.pass("Activity Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.rec1)).click();
            driver.findElement(By.xpath(modelElements.rec2)).click();
            driver.findElement(By.xpath(modelElements.rec3)).click();

            test.pass("Clicked Records", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.clickManualMatchBTN)).click();
            test.pass("Match Dialog", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.approveMatchGroupBTN)).click();

            if(SeleniumClient.checkIfElementIsVisible(driver,By.xpath(modelElements.matchgroupCreatedMessege)))
            {
                test.pass("Match Group Created", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            }
            else
            {
                test.fail("Match Group Not Created", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }


    public static boolean canPeformUnbalancedMatchGroup(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ModelElements modelElements= new ModelElements();
        ReconElement reconElement = new ReconElement();

        try {
            // passing test
            driver.findElement(By.xpath(modelElements.homePageTab)).click();
            test.pass("Home Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.recon_GLD)).click();
            Thread.sleep(7000);
            test.pass("Activity Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.rec1)).click();
            driver.findElement(By.xpath(modelElements.rec2)).click();

            test.pass("Clicked Records", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.clickManualMatchBTN)).click();
            test.pass("Match Dialog", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.approveMatchGroupBTN)).click();

            if(SeleniumClient.checkIfElementIsVisible(driver,By.xpath(modelElements.matchgroupCreatedMessege)))
            {
                test.pass("Match Group Created", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            }
            else
            {
                test.fail("Match Group Not Created", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }

    public static boolean canFilter(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ModelElements modelElements= new ModelElements();
        try {
            // passing test
            driver.findElement(By.xpath(modelElements.homePageTab)).click();
            test.pass("Home Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.recon_GLD)).click();
            Thread.sleep(7000);
            test.pass("Activity Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.rec1)).click();
            driver.findElement(By.xpath(modelElements.clickFilter)).click();
            Thread.sleep(2000);
            test.pass("Filter Dialog", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            Thread.sleep(2000);
            driver.findElement(By.xpath(modelElements.values)).click();

            Thread.sleep(2000);

            driver.findElement(By.xpath(modelElements.valuesOption)).click();

            Thread.sleep(2000);


            driver.findElement(By.xpath(modelElements.clickApply)).click();
            Thread.sleep(5000);
            test.pass(" Filtered", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());


        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }
    public static boolean Collections(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ModelElements modelElements= new ModelElements();
        try {
            // passing test
            driver.findElement(By.xpath(modelElements.homePageTab)).click();
            test.pass("Home Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.recon_GLD)).click();
            Thread.sleep(7000);
            test.pass("Activity Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.rec1)).click();
            driver.findElement(By.xpath(modelElements.collectionDropdown)).click();
            Thread.sleep(2000);
            test.pass("Collection dialog", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

            driver.findElement(By.xpath(modelElements.collectionQuickCollectionBTN)).click();
            Thread.sleep(3000);
            test.pass("Added to Collection", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());


        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }
    public static boolean AssignItems(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ModelElements modelElements= new ModelElements();
        try {
            // passing test
            driver.findElement(By.xpath(modelElements.homePageTab)).click();
            test.pass("Home Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.recon_GLD)).click();
            Thread.sleep(7000);
            test.pass("Activity Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.rec1)).click();
            driver.findElement(By.xpath(modelElements.bulkActionsBTN)).click();
            Thread.sleep(2000);
            test.pass("Bulk Action dialog", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

            driver.findElement(By.xpath(modelElements.amountDCaRROW)).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath(modelElements.tradeDebit)).click();//
            Thread.sleep(2000);
            driver.findElement(By.xpath(modelElements.dateBTN)).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath(modelElements.selectedDate)).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath(modelElements.saveAllBTN)).click();

            test.pass("Assined Items", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());


        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }


    public static boolean canAddReconToContinueusModel(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ModelElements modelElements= new ModelElements();
        try {
            // passing test
            driver.findElement(By.xpath(modelElements.reconInventoryPage)).click();
            test.pass("Recon Inventory", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.newReconciliationBTN)).click();
            test.pass("Reconciliation Dialog", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());



        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }



    public static boolean BulkActionsAssignment(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ModelElements modelElements= new ModelElements();
        try {
            // passing test
            driver.findElement(By.xpath(modelElements.homePageTab)).click();
            test.pass("Home Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.recon_GLD)).click();
            Thread.sleep(7000);
            test.pass("Activity Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.rec1)).click();
            driver.findElement(By.xpath(modelElements.rec2)).click();

            test.pass("Clicked Records", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.btnBulkActions)).click();
            test.pass("Bulk Actions Dialog", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());


            driver.findElement(By.xpath(modelElements.breakCodeArrow)).click();
            driver.findElement(By.xpath(modelElements.breadCodeOption)).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath(modelElements.departmentArrow)).click();
            driver.findElement(By.xpath(modelElements.departmentOption)).click();
            Thread.sleep(2000);

            driver.findElement(By.xpath(modelElements.ExceptionPriorityArrow)).click();
            driver.findElement(By.xpath(modelElements.ExceptionPriorityArrowOption)).click();
            Thread.sleep(2000);
            test.pass("Bulk Actions Dialog Filled", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());

            driver.findElement(By.xpath(modelElements.saveAllBTN)).click();
            test.pass("Bulk Actions saved", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());



        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }

    public static boolean addingSLA(WebDriver driver, HashMap<String, String> testData, ExtentTest test, Properties environment) {
        ModelElements modelElements= new ModelElements();
        try {
            // passing test
            driver.findElement(By.xpath(modelElements.homePageTab)).click();
            test.pass("Home Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.reconInventoryPage)).click();
            test.pass("Recon Inventory", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.prefferedReconciliation)).click();
            test.pass("Reconciliation", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            Thread.sleep(2000);
            driver.findElement(By.xpath(modelElements.processes)).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath(modelElements.assignments)).click();
            Thread.sleep(2000);
            test.pass("Assignment Page", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.submitBTN)).click();
            Thread.sleep(2000);

            driver.findElement(By.xpath(modelElements.dateIcon)).click();
            Thread.sleep(2000);

            driver.findElement(By.xpath(modelElements.setBTN)).click();


            test.pass("Date Dialog", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.save)).click();
            Thread.sleep(2000);
            test.pass("sla saved", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
            driver.findElement(By.xpath(modelElements.saveRecon)).click();
            Thread.sleep(1000);
            test.pass("Recon  saved", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());



        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }


}
