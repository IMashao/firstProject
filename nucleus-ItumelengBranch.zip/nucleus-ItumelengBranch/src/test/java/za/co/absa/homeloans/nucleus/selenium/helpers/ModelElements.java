package za.co.absa.homeloans.nucleus.selenium.helpers;

public class ModelElements {
    public final String  createModelButn="//mat-icon[contains(@class,'mat-icon notranslate fisfont fis-icon-add mat-icon-no-color')]";
    public final String modelName="//input[contains(@ng-reflect-name,'Name')]";
    public final String homePageTab="//mat-icon[@ng-reflect-font-icon='fis-icon-home']";


    public final String reconSides="(//div[contains(@class,'mat-select-arrow')])[6]";
    public final String reconsideType="(//span[contains(@class,'mat-option-text')])[2]";

    public final  String frequency="(//div[contains(@class,'mat-select-arrow')])[8]";
    public final String frequencyName="(//span[contains(@class,'mat-option-text')])[1]";


    public final String modelDescription="//textarea[contains(@data-aid,'new-model-description-input')]";

    public final String  applicationService="//mat-form-field[contains(.,'Application ServiceApplication Service')]";
    public final String  getApplicationServiceType="//span[@class='mat-option-text'][contains(.,'Reconciliation CIB_PROD')]";

    public final String company="//div[@class='mat-form-field-infix'][contains(.,'CompanyCompany')]";
    public  final String getCompanyName="(//span[contains(@class,'mat-option-text')])[1]";

    public final String  context="//mat-form-field[contains(.,'ContextContext')]";
    public final String contextOption="(//span[contains(@class,'mat-option-text')])[1]";

    public final String reconType="//mat-form-field[contains(.,'Recon TypeRecon Type')]";
    public final String reconTypeOption="(//span[contains(@class,'mat-option-text')])[1]";

    public final String rollBalancesReconDate="//div[@class='mat-form-field-infix'][contains(.,'Roll balances forward to reconciliation dateRoll balances forward to reconciliation date')]";
    public final String getRollBalancesReconDateOption="(//span[contains(@class,'mat-option-text')])[1]";

    public final String itemReconciliationField="//div[@class='mat-form-field-infix'][contains(.,'Item Reconciliation fieldItem Reconciliation field')]";
    public final String getItemReconciliationFieldOption="(//span[contains(@class,'mat-option-text')])[1]";

    public final String itemDateField="//div[@class='mat-form-field-infix'][contains(.,'Item Date FieldItem Date Field')]";
    public final String getItemDateFieldOption="(//span[contains(@class,'mat-option-text')])[1]";

    public final String accountBalanceField="//mat-form-field[contains(.,'Account Balance FieldAccount Balance Field')]";
    public final String getAccountBalanceFieldOption="(//span[contains(@class,'mat-option-text')])[1]";

    public final String determineReconciliationDateByMost="//div[@class='mat-form-field-infix'][contains(.,'Determine reconciliation date by most recent balancesDetermine reconciliation date by most recent balances')]";
    public final String getDetermineReconciliationDateByMostOption="(//span[contains(@class,'mat-option-text')])[1]";


    public final String latestDateWhere="//div[@class='mat-form-field-infix'][contains(.,'Latest date whereLatest date where')]";
    public final String getLatestDateWhereOption="(//span[contains(@class,'mat-option-text')])[1]";

    public final String determineDsteIndependency="//mat-select[contains(@data-aid,'new-model-determine-date-select')]";
    public final String getDetermineDsteIndependencyOption="(//span[contains(@class,'mat-option-text')])[1]";

    public  final String reconInventoryPage="//*[@id=\"mat-tab-group_0_ruf-menu-label_1_div_0_ruf-labeled-icon_0_mat-icon_0\"]";

    public final String createRecon="(//span[@class='mat-button-wrapper'][contains(.,'Create')])[1]";

    public final String modelSaved="//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted'][contains(.,'Model saved successfully.')]";


    public  final String ModelMode="(//div[contains(@class,'mat-select-arrow')])[4]";
    public final String  modelModeType="//span[@class='mat-option-text'][contains(.,'Continuous')]";

    public final String continusCnfiguration="(//div[contains(@class,'mat-select-arrow')])[16]";
    public final String continusCnfigurationType="//span[@class='mat-option-text'][contains(.,'Eq Amount')]";
    public final String continueouseCreateButton="(//span[@class='mat-button-wrapper'][contains(.,'Create')])[1]";


    public final String selectModelToEdit="(//span[contains(@class,'cursor-pointer model-name')])[2]";//****
    public final String editedModelName="//input[contains(@formcontrolname,'Name')]";
    public final String saveModelAfterEdit="//span[@class='mat-button-wrapper'][contains(.,'Save Model')]";
    public final String editedModelMessegeSuccess="//span[contains(.,'Saved Successfully.')]";


    public final String selectModelToMatch="(//mat-icon[contains(@class,'rotate mat-icon notranslate fisfont fis-icon-chevron-double mat-icon-no-color')])[19]";

    public final String clickRecord1="//*[@id=\"activityPageItemGrid_div_0_ag-grid-angular_0\"]/div/div[2]/div[1]/div[3]/div[2]/div/div/div[3]/div[16]";
    public final String clickRecord2="//*[@id=\"activityPageItemGrid_div_0_ag-grid-angular_0\"]/div/div[2]/div[1]/div[3]/div[2]/div/div/div[4]/div[16]";

    public final String clickManualMatchBTN="//*[@id=\"button-bar-main_0_ruf-toolbar-row_0_mat-button-toggle-group_0_mat-button-toggle_0_im-button-content_1_div_0_mat-icon_0\"]";
    public final String approveMatchGroupBTN="//div[@class='button-label'][contains(.,'Approve')]";
    public final String  matchgroupCreatedMessege="//span[contains(.,'New match group created for selected item(s).')]";


    //marchingWriteOffs
    public final String reconToMatch="/html/body/nextgen-root/div/ruf-app-canvas/nextgen-layout/mat-sidenav-container/mat-sidenav-content/div[2]/div/nextgen-home-tab/mat-card/div/div/div/nextgen-detail-recon-list/mat-card/nextgen-recon-list/div/ag-grid-angular/div/div[2]/div[1]/div[3]/div[2]/div/div/div[19]/div[6]/nextgen-recon-name-cell-renderer/span[2]";
    public final String proposedMessege="//span[contains(.,'New match group created for selected item(s).')]";
    public final String clickRecord11="//*[@id=\"activityPageItemGrid_div_0_ag-grid-angular_0\"]/div/div[2]/div[1]/div[3]/div[2]/div/div/div[5]/div[5]";
    public final String clickRecord22="//*[@id=\"activityPageItemGrid_div_0_ag-grid-angular_0\"]/div/div[2]/div[1]/div[3]/div[2]/div/div/div[6]/div[5]";
    public final String proposeBTN="//div[@class='button-label'][contains(.,'Propose')]";

    public final String sideMenu="//mat-icon[contains(@class,'mat-icon notranslate fisfont fis-icon-menu mat-icon-no-color')]";
    public final String dashboard="//span[@id='dashboardLabel_span_0']";
    public final String selectedDashboard="//span[contains(@id,'0')][contains(.,'My Dashboard')]";
    public final String successtDashBoard="//span[@class='title-text'][contains(.,'Items grouped by Match Status of type Pie Chart')]";

    //Many Match Group
    public final String recon_GLD="//span[@class='cursor-pointer primary'][contains(.,'ABSA Confirmations_Frgn Exch')]";
    public final String rec1="//*[@id=\"activityPageItemGrid_div_0_ag-grid-angular_0\"]/div/div[2]/div[1]/div[3]/div[2]/div/div/div[8]/div[7]/span/div";

    public final String rec2="//*[@id=\"activityPageItemGrid_div_0_ag-grid-angular_0\"]/div/div[2]/div[1]/div[3]/div[2]/div/div/div[9]/div[7]/span/div";
    public final String rec3="//*[@id=\"activityPageItemGrid_div_0_ag-grid-angular_0\"]/div/div[2]/div[1]/div[3]/div[2]/div/div/div[10]/div[7]/span/div";
    public final String clickApply="//*[@id=\"activityPageItemGrid_div_0_ag-grid-angular_0\"]/div/div[5]/div/div/div[2]/div/im-filter-cell/form/div/div[5]/button[1]/span";
    public final String clickFilter="//*[@id=\"activityPageItemGrid_div_0_ag-grid-angular_0\"]/div/div[2]/div[1]/div[1]/div[2]/div/div/div[1]/div[2]/span/span";

    public final String collectionDropdown="//*[@id=\"button-bar-main_0_ruf-toolbar-row_0_mat-button-toggle-group_2_mat-button-toggle_0_mat-icon_0\"]";
    public final  String collectionQuickCollectionBTN="//span[@rufmarginleft='small'][contains(.,'Quick collection')]";
    public final String bulkActionsBTN="//*[@id=\"button-bar-main_0_ruf-toolbar-row_0_mat-button-toggle-group_2_mat-button-toggle_0_im-button-content_1_div_0\"]/span";

    public final String amountDCaRROW="(//mat-icon[contains(@class,'mat-icon notranslate fisfont fis-icon-arrow-down mat-icon-no-color')])[5]";
    public final String tradeDebit="(//span[contains(@class,'mat-option-text')])[2]";///

    public final String dateBTN="(//button[contains(@aria-haspopup,'dialog')])[2]";
    public final String selectedDate="//div[@class='mat-calendar-body-cell-content mat-calendar-body-today'][contains(.,'18')]";

    public final String saveAllBTN="//span[@class='mat-button-wrapper'][contains(.,'Save All')]";


    public final String newReconciliationBTN="//span[@class='align-self ruf-foreground-primary'][contains(.,'New Reconciliation')]";
    public final String continueousModel="//span[@class='mat-option-text'][contains(.,'Testing Testing sws w454sssqwegffg3le')]";
    public final String btnBulkActions="//*[@id=\"button-bar-main_0_ruf-toolbar-row_0_mat-button-toggle-group_2_mat-button-toggle_0_im-button-content_1_div_0\"]/span";

    public final String breakCodeArrow="(//mat-icon[contains(@class,'mat-icon notranslate fisfont fis-icon-arrow-down mat-icon-no-color')])[1]";
    public final String breadCodeOption="//span[@class='mat-option-text'][contains(.,'<None>')]";

    public  final String departmentArrow="(//mat-icon[contains(@class,'mat-icon notranslate fisfont fis-icon-arrow-down mat-icon-no-color')])[2]";
    public final String departmentOption="//span[@class='mat-option-text'][contains(.,'<None>')]";

    public  final String ExceptionPriorityArrow="(//mat-icon[contains(@class,'mat-icon notranslate fisfont fis-icon-arrow-down mat-icon-no-color')])[3]";
    public final String ExceptionPriorityArrowOption="//span[@class='mat-option-text'][contains(.,'<None>')]";


    //adding SLA
    public final String prefferedReconciliation="(//mat-icon[contains(@class,'fis-icon-rotate-270 mat-icon notranslate fisfont fis-icon-chevron-double mat-icon-no-color')])[10]";
    public final String processes="//a[contains(@id,'0')][@ng-reflect-ruf-id='dynamic_sidemenu_processes'][contains(.,'Processes')]";
    public final String assignments="//span[contains(@id,'0')][contains(.,'Assignment')]";
    public final String submitBTN="/html/body/nextgen-root/div/ruf-app-canvas/nextgen-layout/mat-sidenav-container/mat-sidenav-content/div[2]/div/nextgen-inventory-recon-details-tab/div[2]/div/div[2]/div[2]/nextgen-inventory-recon-processes/div/div[2]/div/nextgen-recon-inventory-status/div/div[2]/div/button[1]/span";
    public final String save="(//span[@class='mat-button-wrapper'][contains(.,'Save')])[2]";
    public final String saveRecon="//span[@class='mat-button-wrapper'][contains(.,'Save Recon')]";

    public final String values="//*[@id=\"activityPageItemGrid_div_0_ag-grid-angular_0\"]/div/div[5]/div/div/div[2]/div/im-filter-cell/form/div/div[3]/div/mat-form-field/div/div[1]/div";
    public final String valuesOption="//span[@class='mat-option-text'][contains(.,'Corporate_CParty')]";


    public final String dateIcon="//mat-icon[contains(@data-aid,'RI-sla-timer-icon')]";
    public final String setBTN="//span[@class='owl-dt-control-content owl-dt-control-button-content'][contains(.,'Set')]";








}
