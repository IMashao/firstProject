package za.co.absa.homeloans.nucleus.selenium;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import za.co.absa.homeloans.automation.nucleus.data.DataClient;
import za.co.absa.homeloans.automation.nucleus.selenium.SeleniumClient;

import java.io.IOException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class LoginTest {

    public ExtentHtmlReporter htmlReporter;
    public ExtentReports extent;
    public ExtentTest test;

    WebDriver driver;
    Properties environment = new Properties();
    ArrayList<HashMap<String, String>> testData = new ArrayList<>();

    SeleniumClient seleniumClient = new SeleniumClient();

    @Before
    public void before() {
        environment = DataClient.getProperties("src/test/resources/environment.properties");
        testData = DataClient.getAllRowsFromExcelFile("src/test/resources/IntellimatchTestData.xlsx", "Login");
        extent = new ExtentReports();
        htmlReporter = new ExtentHtmlReporter(environment.getProperty("reports") + "LoginReport.html");
        extent = new ExtentReports();
        htmlReporter.config().setDocumentTitle("Login Report");
        htmlReporter.config().setTheme(Theme.STANDARD);
    }

    @Test
    public void seleniumTest() throws Exception {
        SeleniumClient seleniumClient = new SeleniumClient();
        driver = seleniumClient.getChromeDriver();
        driver.get(environment.getProperty("baseUrl"));

        for (int i = 0; i < testData.size(); i++) {
            test = extent.createTest(testData.get(i).get("TestID") + " " + testData.get(i).get("TestDescription"));

            // passing test
            if (SeleniumClient.checkIfElementIsVisible(driver, By.id("mat-tab-group_0_ruf-menu-label_0_div_0_ruf-labeled-icon_0_mat-icon_0"))) {

                //positive testing
                if (testData.get(i).get("ExpectedResult").equalsIgnoreCase("Success")) {
                    if (driver.getCurrentUrl().equals("http://zaurnbmweb0106/ISUITE/NextGen/#/home")) {
                        Thread.sleep(3000);
                        test.pass("Success Home page ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                    } else {
                        test.fail("Unsuccessful Home page landing ", MediaEntityBuilder.createScreenCaptureFromPath(SeleniumClient.takeScreenShot(driver, environment.getProperty("scrreenshotPath"))).build());
                        reinitializeDriver(driver);
                    }
                }
            } else {
                //Fail test
                reinitializeDriver(driver);
            }
        }

        driver.quit();
    }

    public void reinitializeDriver(WebDriver driver) {
        driver.get(environment.getProperty("baseUrl"));
    }

    @After
    public void endTest() {
        extent.attachReporter(htmlReporter);
        extent.flush();
    }
}
