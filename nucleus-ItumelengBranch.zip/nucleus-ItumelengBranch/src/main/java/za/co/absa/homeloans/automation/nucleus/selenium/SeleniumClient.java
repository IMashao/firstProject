package za.co.absa.homeloans.automation.nucleus.selenium;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

public class SeleniumClient {
    public WebDriver driver;

    public WebDriver getChromeDriver() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/selenium/drivers/chromedriver.exe");
        driver = new ChromeDriver();
        return this.driver;
    }

    public static boolean checkIfElementIsVisible(WebDriver driver, By by) {
        for (int i = 0; i < 15; i++) {
            try {
                driver.findElement(by);
                return true;
            } catch (Exception ex) {
                ex.printStackTrace();
                try {
                    Thread.sleep(1000);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return false;
    }

    public static String takeScreenShot(WebDriver driver, String screenshotName) {

        String dateName = new SimpleDateFormat("yyyyMMddhhmmssSSS").format(new Date());

        TakesScreenshot ts = (TakesScreenshot) driver;
        File source = ts.getScreenshotAs(OutputType.FILE);
        System.out.println("the Screenshot is taken");

        String destination = screenshotName + dateName + ".png";

        File finalDestination = new File(destination);
        try {
            FileUtils.copyFile(source, finalDestination);
            Thread.sleep(100);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return destination;
    }
}
