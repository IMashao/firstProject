package za.co.absa.homeloans.automation.nucleus.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class DataClient {
    public static Properties getProperties(String filePath) {
        Properties p = new Properties();
        try {
            FileReader reader = new FileReader(filePath);

            p.load(reader);
            System.out.println(p);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return p;
    }

    public static ArrayList<HashMap<String, String>> getAllRowsFromExcelFile(String fileName, String sheetName) {
        try {
            ArrayList<HashMap<String, String>> allRows = new ArrayList<>();
            FileInputStream fis = new FileInputStream(new File(fileName));
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            XSSFSheet sheet = wb.getSheet(sheetName);

            for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
                HashMap<String, String> temps = new HashMap<>();
                for (int a = 0; a < sheet.getRow(0).getPhysicalNumberOfCells(); a++) {

                    FormulaEvaluator formulaEvaluator = wb.getCreationHelper().createFormulaEvaluator();
                    try {
                        sheet.getRow(i).getCell(a).getCellType();
                    } catch (Exception e) {
                        temps.put(sheet.getRow(0).getCell(a).getStringCellValue(), "NULL");
                        continue;
                    }

                    switch (formulaEvaluator.evaluateInCell(sheet.getRow(i).getCell(a)).getCellType()) {
                        case Cell.CELL_TYPE_BLANK:
                            temps.put(sheet.getRow(0).getCell(a).getStringCellValue(), "NULL");
                            break;
                        case Cell.CELL_TYPE_NUMERIC:
                            temps.put(sheet.getRow(0).getCell(a).getStringCellValue(), String.valueOf(sheet.getRow(i).getCell(a).getNumericCellValue()));
                            break;
                        case Cell.CELL_TYPE_STRING:
                            temps.put(sheet.getRow(0).getCell(a).getStringCellValue(), sheet.getRow(i).getCell(a).getStringCellValue());
                            break;
                    }
                }
                allRows.add(temps);
            }
            System.out.print(allRows);
            return allRows;
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<HashMap<String, String>>();
        }

    }

    public static ArrayList<HashMap<String, String>> getAllRowsFromExcelFileById(String fileName, String sheetName, String id) {
        try {
            ArrayList<HashMap<String, String>> allRows = new ArrayList<>();
            FileInputStream fis = new FileInputStream(new File(fileName));
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            XSSFSheet sheet = wb.getSheet(sheetName);

            for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
                HashMap<String, String> temps = new HashMap<>();
                if (id.equalsIgnoreCase(String.valueOf(sheet.getRow(i).getCell(0).getNumericCellValue()))) {
                    for (int a = 0; a < sheet.getRow(0).getPhysicalNumberOfCells(); a++) {
                        FormulaEvaluator formulaEvaluator = wb.getCreationHelper().createFormulaEvaluator();
                        try {
                            sheet.getRow(i).getCell(a).getCellType();
                        } catch (Exception e) {
                            temps.put(sheet.getRow(0).getCell(a).getStringCellValue(), "NULL");
                            continue;
                        }
                        switch (formulaEvaluator.evaluateInCell(sheet.getRow(i).getCell(a)).getCellType()) {
                            case Cell.CELL_TYPE_BLANK:
                                temps.put(sheet.getRow(0).getCell(a).getStringCellValue(), "NULL");
                                break;
                            case Cell.CELL_TYPE_NUMERIC:
                                temps.put(sheet.getRow(0).getCell(a).getStringCellValue(), String.valueOf(sheet.getRow(i).getCell(a).getNumericCellValue()));
                                break;
                            case Cell.CELL_TYPE_STRING:
                                temps.put(sheet.getRow(0).getCell(a).getStringCellValue(), sheet.getRow(i).getCell(a).getStringCellValue());
                                break;
                        }
                    }
                    allRows.add(temps);
                }

            }
            System.out.print(allRows);
            return allRows;
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<HashMap<String, String>>();
        }

    }

    public static String loadFileToString(String fileName) {

        try {
            InputStream is = new FileInputStream(fileName);
            BufferedReader buf = new BufferedReader(new InputStreamReader(is));
            String line = buf.readLine();
            StringBuilder sb = new StringBuilder();

            while (line != null) {
                sb.append(line).append("\n");
                line = buf.readLine();
            }

            String fileAsString = sb.toString();
            System.out.println("Contents : " + fileAsString);

            return fileAsString;

        } catch (Exception ex) {
            ex.printStackTrace();
            return "";
        }
    }

    public static String prettyJSON(String json) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        JsonParser jp = new JsonParser();
        JsonElement je = jp.parse(json);
        String prettyJsonString = gson.toJson(je);

        return prettyJsonString;
    }

    public static String extractString(String jsObject) {
        Map jsonJavaRootObject = new Gson().fromJson(jsObject, Map.class);

        String description = jsonJavaRootObject.get("description").toString();

        return description;
    }
}
